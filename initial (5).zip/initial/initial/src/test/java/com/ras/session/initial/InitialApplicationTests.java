package com.ras.session.initial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitialApplicationTests {

	@Test
	void contextLoads() {
	}

}
