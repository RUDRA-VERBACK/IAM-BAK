package com.ras.session.initial.repository;

import com.ras.session.initial.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}









