package com.ras.session.initial.service.Impl;

//package com.ras.session.initial.service.Impl;

import com.ras.session.initial.DTO.RoleDTO;
import com.ras.session.initial.DTO.UserDTO;
import com.ras.session.initial.entity.Role;
import com.ras.session.initial.entity.User;
import com.ras.session.initial.repository.RoleRepository;
import com.ras.session.initial.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

public interface UserService {
    UserDTO saveUser(UserDTO userDTO);
    RoleDTO saveRole(RoleDTO roleDTO);
    void addRoleToUser(String username, String roleName);
    UserDTO getUser(String username);
    List<UserDTO> getUsers();
}
