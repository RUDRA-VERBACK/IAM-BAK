package com.ras.session.initial.service.impl;

import com.ras.session.initial.entity.FinancialData;
import com.ras.session.initial.repository.FinancialDataRepository;
import com.ras.session.initial.service.FinancialDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FinancialDataServiceImpl implements FinancialDataService {

    @Autowired
    private FinancialDataRepository financialDataRepository;

    @Override
    public FinancialData saveFinancialData(FinancialData financialData) {
        return financialDataRepository.save(financialData);
    }

    @Override
    public FinancialData getFinancialData(Long id) {
        return financialDataRepository.findById(id).orElse(null);
    }

    @Override
    public List<FinancialData> getFinancialDataByData(String data) {
        return financialDataRepository.findByData(data);
    }

    @Override
    public List<FinancialData> getFinancialDataByValueGreaterThan(Double value) {
        return financialDataRepository.findByValueGreaterThan(value);
    }

    @Override
    public List<FinancialData> getFinancialDataByDataAndValueRange(String data, Double minValue, Double maxValue) {
        return financialDataRepository.findByDataAndValueBetween(data, minValue, maxValue);
    }
}
