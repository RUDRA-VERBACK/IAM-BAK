package com.ras.session.initial.repository;

import com.ras.session.initial.entity.BusinessIntelligence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BusinessIntelligenceRepository extends JpaRepository<BusinessIntelligence, Long> {
    //
}