package com.ras.session.initial.DTO;

public class RoleDTO {
    private Long id;
    private String name;

    // Constructors, Getters, and Setters
}
