package com.ras.session.initial.service;

import com.ras.session.initial.entity.FinancialData;
import java.util.List;

public interface FinancialDataService {

    FinancialData saveFinancialData(FinancialData financialData);

    FinancialData getFinancialData(Long id);

    List<FinancialData> getFinancialDataByData(String data);

    List<FinancialData> getFinancialDataByValueGreaterThan(Double value);

    List<FinancialData> getFinancialDataByDataAndValueRange(String data, Double minValue, Double maxValue);
}