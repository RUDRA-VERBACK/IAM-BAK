package com.ras.session.initial.DTO;

public class RiskAssessmentDTO {
}
