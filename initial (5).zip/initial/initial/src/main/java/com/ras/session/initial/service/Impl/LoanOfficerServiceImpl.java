package com.ras.session.initial.service.Impl;

import com.ras.session.initial.DTO.LoanApplicationDTO;
import com.ras.session.initial.entity.LoanApplication;
import com.ras.session.initial.entity.TransactionData;
import com.ras.session.initial.repository.LoanApplicationRepository;
import com.ras.session.initial.repository.TransactionDataRepository;
import com.ras.session.initial.service.LoanOfficerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanOfficerServiceImpl implements LoanOfficerService {

    @Autowired
    private LoanApplicationRepository loanApplicationRepository;
    @Autowired
    private TransactionDataRepository transactionDataRepository;
    @Override
    public String processLoanApplication(LoanApplicationDTO loanApplicationDTO) {
        // Convert DTO to Entity
        LoanApplication loanApplication = new LoanApplication();
        loanApplication.setCustomerId(loanApplicationDTO.getCustomerId());
        loanApplication.setLoanAmount(loanApplicationDTO.getLoanAmount());
        loanApplication.setLoanPurpose(loanApplicationDTO.getLoanPurpose());
        loanApplication.setApplicationStatus(loanApplicationDTO.getApplicationStatus());

        // Save the loan application
        loanApplicationRepository.save(loanApplication);
        return "Loan application processed successfully";
    }

    @Override
    public LoanApplicationDTO reviewLoanApplication(Long applicationId) {
        // Fetch application from repository
        LoanApplication loanApplication = loanApplicationRepository.findById(applicationId).orElse(null);
        if (loanApplication != null) {
            // Convert Entity to DTO
            LoanApplicationDTO loanApplicationDTO = new LoanApplicationDTO();
            loanApplicationDTO.setApplicationId(loanApplication.getApplicationId());
            loanApplicationDTO.setCustomerId(loanApplication.getCustomerId());
            loanApplicationDTO.setLoanAmount(loanApplication.getLoanAmount());
            loanApplicationDTO.setLoanPurpose(loanApplication.getLoanPurpose());
            loanApplicationDTO.setApplicationStatus(loanApplication.getApplicationStatus());
            return loanApplicationDTO;
        }
        return null;
    }

    @Override
    public TransactionData accessFinancialInfo(Long customerId) {
        // Fetch financial info from repository
        return transactionDataRepository.findById(customerId).orElse(null);
    }

    @Override
    public String performOtherOperations() {
        // Perform other operations
        return "Performed other operations";
    }
}