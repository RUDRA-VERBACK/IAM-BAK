package com.ras.session.initial.DTO;

public class ReportDTO {
    private Long id;
    private String title;
    private String content;
    // Other fields and getters/setters
}