package com.ras.session.initial.controller;

import com.ras.session.initial.DTO.CustomerInfoDTO;
import com.ras.session.initial.DTO.TransactionDataDTO;
import com.ras.session.initial.service.BranchManagerService;
import com.ras.session.initial.service.Impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.Duration;
import java.time.Instant;

@RestController
@RequestMapping("/api/branch-manager")
public class BranchManagerController {

    @Autowired
    private UserService userService; // Service to handle user-related operations

    @Autowired
    private BranchManagerService branchManagerService; // Service to handle branch manager operations

    // Login endpoint
    @PostMapping("/login")
    public ResponseEntity<String> login(HttpServletRequest request, HttpServletResponse response,
                                        @RequestParam String username, @RequestParam String password) {
        Authentication authentication = userService.authenticate(username, password);

        if (authentication != null && authentication.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            HttpSession session = request.getSession(true);
            session.setAttribute("user", username); // Store username in session

            // Set session cookie (handled automatically by Spring Security)
            response.addCookie(new javax.servlet.http.Cookie("SESSIONID", session.getId()));

            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    // Logout endpoint
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate(); // Invalidate session
        }

        // Remove session cookie
        javax.servlet.http.Cookie cookie = new javax.servlet.http.Cookie("SESSIONID", null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.ok("Logout successful");
    }

    // Check inactivity and show warning
    @GetMapping("/check-inactivity")
    public ResponseEntity<String> checkInactivity(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session not found");
        }

        Instant lastAccessedTime = Instant.ofEpochMilli(session.getLastAccessedTime());
        Instant currentTime = Instant.now();
        Duration inactivityDuration = Duration.between(lastAccessedTime, currentTime);

        if (inactivityDuration.toSeconds() > 120) { // 120 seconds
            return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body("Inactivity warning");
        }

        return ResponseEntity.ok("User is active");
    }

    @PreAuthorize("hasAuthority('FULL_BRANCH_ACCESS')")
    @GetMapping("/branch-operations")
    public ResponseEntity<String> manageBranchOperations() {
        return branchManagerService.manageBranchOperations();
    }

    @PreAuthorize("hasAuthority('APPROVE_LARGE_TRANSACTIONS')")
    @PostMapping("/transactions/approve")
    public ResponseEntity<String> approveLargeTransaction(@RequestBody TransactionDataDTO transactionDTO) {
        return branchManagerService.approveLargeTransaction(transactionDTO);
    }

    @PreAuthorize("hasAuthority('ACCESS_DETAILED_CUSTOMER_INFO')")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<CustomerInfoDTO> getDetailedCustomerInfo(@PathVariable Long customerId) {
        return branchManagerService.getDetailedCustomerInfo(customerId);
    }

    @PreAuthorize("hasAuthority('OVERSIGHT_COMPLIANCE_SECURITY')")
    @GetMapping("/compliance-security")
    public ResponseEntity<String> overseeComplianceAndSecurity() {
        return branchManagerService.overseeComplianceAndSecurity();
    }
}