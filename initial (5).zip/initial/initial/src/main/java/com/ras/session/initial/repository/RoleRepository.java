package com.ras.session.initial.repository;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
}

