package com.ras.session.initial.controller;

import com.ras.session.initial.DTO.*;
import com.ras.session.initial.service.FinancialDataService;
import com.ras.session.initial.entity.FinancialData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/financial-analyst")
public class FinancialAnalystController {

    @Autowired
    private UserService userService;

    @Autowired
    private FinancialDataService financialDataService;

    @PostMapping("/login")
    public ResponseEntity<String> login(HttpServletRequest request, HttpServletResponse response,
                                        @RequestParam String username, @RequestParam String password) {
        Authentication authentication = userService.authenticate(username, password);

        if (authentication != null && authentication.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            HttpSession session = request.getSession(true);
            session.setAttribute("user", username);

            response.addCookie(new javax.servlet.http.Cookie("SESSIONID", session.getId()));

            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate();
        }

        javax.servlet.http.Cookie cookie = new javax.servlet.http.Cookie("SESSIONID", null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.ok("Logout successful");
    }

    @GetMapping("/check-inactivity")
    public ResponseEntity<String> checkInactivity(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session not found");
        }

        Instant lastAccessedTime = Instant.ofEpochMilli(session.getLastAccessedTime());
        Instant currentTime = Instant.now();
        Duration inactivityDuration = Duration.between(lastAccessedTime, currentTime);

        if (inactivityDuration.toSeconds() > 120) {
            return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body("Inactivity warning");
        }

        return ResponseEntity.ok("User is active");
    }

    @PreAuthorize("hasAuthority('ACCESS_FINANCIAL_DATA')")
    @GetMapping("/financial-data")
    public ResponseEntity<List<FinancialDataDTO>> accessFinancialData() {
        List<FinancialData> financialDataList = financialDataService.getFinancialDataByData("someData"); // Example usage
        List<FinancialDataDTO> financialDataDTOs = financialDataList.stream()
                .map(data -> new FinancialDataDTO(data.getId(), data.getData(), data.getValue()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(financialDataDTOs);
    }

    @PreAuthorize("hasAuthority('GENERATE_REPORTS')")
    @PostMapping("/generate-report")
    public ResponseEntity<ReportDTO> generateReport(@RequestBody ReportDTO reportDTO) {
        // Logic to generate and analyze financial reports
        ReportDTO report = new ReportDTO(); // Populate this with actual data
        return ResponseEntity.ok(report);
    }

    @PreAuthorize("hasAuthority('LIMITED_CUSTOMER_INFO_ACCESS')")
    @GetMapping("/customer-info/{customerId}")
    public ResponseEntity<CustomerInfoDTO> getLimitedCustomerInfo(@PathVariable Long customerId) {
        // Logic to get limited customer personal information
        CustomerInfoDTO customerDTO = new CustomerInfoDTO(); // Populate this with actual data
        return ResponseEntity.ok(customerDTO);
    }

    @PreAuthorize("hasAuthority('ACCESS_BUSINESS_INTELLIGENCE')")
    @GetMapping("/business-intelligence")
    public ResponseEntity<BusinessIntelligenceDTO> accessBusinessIntelligence() {
        // Logic to access business intelligence tools
        BusinessIntelligenceDTO businessIntelligence = new BusinessIntelligenceDTO(); // Populate this with actual data
        return ResponseEntity.ok(businessIntelligence);
    }
}