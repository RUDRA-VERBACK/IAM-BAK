package com.ras.session.initial.service.Impl.;

import com.ras.session.initial.DTO.CustomerInfoDTO;
import com.ras.session.initial.DTO.TransactionDataDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;

public interface BranchManagerService {
    ResponseEntity<String> manageBranchOperations();

    ResponseEntity<String> approveLargeTransaction(TransactionDataDTO transactionDTO);

    ResponseEntity<CustomerInfoDTO> getDetailedCustomerInfo(Long customerId);

    ResponseEntity<String> overseeComplianceAndSecurity();
}