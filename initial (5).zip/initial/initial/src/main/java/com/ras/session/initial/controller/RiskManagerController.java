package com.ras.session.initial.controller;

import com.ras.session.initial.DTO.*;
import com.ras.session.initial.service.Impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.Duration;
import java.time.Instant;

@RestController
@RequestMapping("/api/risk-manager")
public class RiskManagerController {

    @Autowired
    private UserService userService; // Service to handle user-related operations

    // Login endpoint
    @PostMapping("/login")
    public ResponseEntity<String> login(HttpServletRequest request, HttpServletResponse response,
                                        @RequestParam String username, @RequestParam String password) {
        Authentication authentication = userService.authenticate(username, password);

        if (authentication != null && authentication.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            HttpSession session = request.getSession(true);
            session.setAttribute("user", username); // Store username in session

            // Set session cookie (handled automatically by Spring Security)
            response.addCookie(new javax.servlet.http.Cookie("SESSIONID", session.getId()));

            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    // Logout endpoint
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate(); // Invalidate session
        }

        // Remove session cookie
        javax.servlet.http.Cookie cookie = new javax.servlet.http.Cookie("SESSIONID", null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.ok("Logout successful");
    }

    // Check inactivity and show warning
    @GetMapping("/check-inactivity")
    public ResponseEntity<String> checkInactivity(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session not found");
        }

        Instant lastAccessedTime = Instant.ofEpochMilli(session.getLastAccessedTime());
        Instant currentTime = Instant.now();
        Duration inactivityDuration = Duration.between(lastAccessedTime, currentTime);

        if (inactivityDuration.toSeconds() > 120) { // 120 seconds
            return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body("Inactivity warning");
        }

        return ResponseEntity.ok("User is active");
    }

    @PreAuthorize("hasAuthority('ACCESS_RISK_ASSESSMENT')")
    @GetMapping("/risk-assessment")
    public ResponseEntity<RiskAssessmentDTO> accessRiskAssessmentTools() {
        // Logic to access risk assessment tools and data
        RiskAssessmentDTO riskAssessmentDTO = new RiskAssessmentDTO(); // Populate with actual data
        return ResponseEntity.ok(riskAssessmentDTO);
    }

    @PreAuthorize("hasAuthority('MONITOR_MANAGE_RISK')")
    @GetMapping("/manage-risk")
    public ResponseEntity<String> monitorAndManageRisk() {
        // Logic to monitor and manage the bank’s risk exposure
        return ResponseEntity.ok("Risk managed successfully");
    }

    @PreAuthorize("hasAuthority('ACCESS_DETAILED_TRANSACTION_DATA')")
    @GetMapping("/transaction-data")
    public ResponseEntity<TransactionDataDTO> accessDetailedTransactionData() {
        // Logic to access detailed transaction and financial data
        TransactionDataDTO transactionDataDTO = new TransactionDataDTO(); // Populate with actual data
        return ResponseEntity.ok(transactionDataDTO);
    }

    @PreAuthorize("hasAuthority('OVERSIGHT_RISK_MITIGATION')")
    @GetMapping("/risk-mitigation")
    public ResponseEntity<String> oversightRiskMitigation() {
        // Logic to oversee risk mitigation strategies
        return ResponseEntity.ok("Risk mitigation oversight performed successfully");
    }
}