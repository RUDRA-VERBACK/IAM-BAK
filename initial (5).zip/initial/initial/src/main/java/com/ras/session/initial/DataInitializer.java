package com.ras.session.initial;

import com.ras.session.initial.repository.*;
import com.ras.session.initial.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public void run(String... args) throws Exception {
        // Define permissions for Branch Manager role
        Set<String> branchManagerPermissions = new HashSet<>();
        branchManagerPermissions.add("FULL_BRANCH_ACCESS");
        branchManagerPermissions.add("APPROVE_LARGE_TRANSACTIONS");
        branchManagerPermissions.add("ACCESS_DETAILED_CUSTOMER_INFO");
        branchManagerPermissions.add("OVERSIGHT_COMPLIANCE_SECURITY");

        // Create and save Branch Manager role
        Role branchManagerRole = new Role("BRANCH_MANAGER", branchManagerPermissions);
        roleRepository.save(branchManagerRole);

        // Define permissions for Loan Officer role
        Set<String> loanOfficerPermissions = new HashSet<>();
        loanOfficerPermissions.add("ACCESS_LOAN_PROCESSING");
        loanOfficerPermissions.add("REVIEW_LOAN_APPLICATIONS");
        loanOfficerPermissions.add("ACCESS_DETAILED_FINANCIAL_INFO");
        loanOfficerPermissions.add("LIMITED_ACCESS_TO_OTHER_OPERATIONS");

        // Create and save Loan Officer role
        Role loanOfficerRole = new Role("LOAN_OFFICER", loanOfficerPermissions);
        roleRepository.save(loanOfficerRole);

        // Define permissions for Financial Analyst role
        Set<String> financialAnalystPermissions = new HashSet<>();
        financialAnalystPermissions.add("ACCESS_FINANCIAL_DATA");
        financialAnalystPermissions.add("GENERATE_REPORTS");
        financialAnalystPermissions.add("LIMITED_CUSTOMER_INFO_ACCESS");
        financialAnalystPermissions.add("ACCESS_BUSINESS_INTELLIGENCE");

        // Create and save Financial Analyst role
        Role financialAnalystRole = new Role("FINANCIAL_ANALYST", financialAnalystPermissions);
        roleRepository.save(financialAnalystRole);

        // Define permissions for Risk Manager role
        Set<String> riskManagerPermissions = new HashSet<>();
        riskManagerPermissions.add("ACCESS_RISK_ASSESSMENT_TOOLS");
        riskManagerPermissions.add("MANAGE_RISK_EXPOSURE");
        riskManagerPermissions.add("ACCESS_TRANSACTION_AND_FINANCIAL_DATA");
        riskManagerPermissions.add("OVERSIGHT_RISK_MITIGATION_STRATEGIES");

        // Create and save Risk Manager role
        Role riskManagerRole = new Role("RISK_MANAGER", riskManagerPermissions);
        roleRepository.save(riskManagerRole);

        // Define permissions for Executive Management role
        Set<String> executivePermissions = new HashSet<>();
        executivePermissions.add("FULL_ACCESS_TO_OPERATIONS");
        executivePermissions.add("MAKE_STRATEGIC_DECISIONS");
        executivePermissions.add("APPROVE_MAJOR_TRANSACTIONS");
        executivePermissions.add("ACCESS_DETAILED_FINANCIAL_OPERATIONS_CUSTOMER_DATA");
        executivePermissions.add("OVERSIGHT_OF_BANK_PERFORMANCE");

        // Create and save Executive Management role
        Role executiveRole = new Role("EXECUTIVE", executivePermissions);
        roleRepository.save(executiveRole);
    }
}