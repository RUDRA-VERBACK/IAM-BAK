package com.ras.session.initial.controller;

import com.ras.session.initial.DTO.DetailedDTO;
import com.ras.session.initial.service.Impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.time.Duration;
import java.time.Instant;

@RestController
@RequestMapping("/api/executive-management")
public class ExecutiveManagementController {

    @Autowired
    private UserService userService; // Service to handle user-related operations

    // Login endpoint
    @PostMapping("/login")
    public ResponseEntity<String> login(HttpServletRequest request, HttpServletResponse response,
                                        @RequestParam String username, @RequestParam String password) {
        Authentication authentication = userService.authenticate(username, password);

        if (authentication != null && authentication.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            HttpSession session = request.getSession(true);
            session.setAttribute("user", username); // Store username in session

            // Set session cookie (handled automatically by Spring Security)
            response.addCookie(new javax.servlet.http.Cookie("SESSIONID", session.getId()));

            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    // Logout endpoint
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);

        if (session != null) {
            session.invalidate(); // Invalidate session
        }

        // Remove session cookie
        javax.servlet.http.Cookie cookie = new javax.servlet.http.Cookie("SESSIONID", null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.ok("Logout successful");
    }

    // Check inactivity and show warning
    @GetMapping("/check-inactivity")
    public ResponseEntity<String> checkInactivity(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session not found");
        }

        Instant lastAccessedTime = Instant.ofEpochMilli(session.getLastAccessedTime());
        Instant currentTime = Instant.now();
        Duration inactivityDuration = Duration.between(lastAccessedTime, currentTime);

        if (inactivityDuration.toSeconds() > 120) { // 120 seconds
            return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body("Inactivity warning");
        }

        return ResponseEntity.ok("User is active");
    }

    @PreAuthorize("hasAuthority('FULL_ACCESS')")
    @GetMapping("/full-access")
    public ResponseEntity<String> fullAccess() {
        // Logic to access all areas of the bank’s operations
        return ResponseEntity.ok("Full access granted");
    }

    @PreAuthorize("hasAuthority('STRATEGIC_DECISIONS')")
    @PostMapping("/strategic-decisions")
    public ResponseEntity<String> makeStrategicDecisions() {
        // Logic to make strategic decisions and approve major transactions
        return ResponseEntity.ok("Strategic decision made");
    }

    @PreAuthorize("hasAuthority('ACCESS_DETAILED_DATA')")
    @GetMapping("/detailed-data")
    public ResponseEntity<DetailedDTO> accessDetailedData() {
        // Logic to access detailed financial, operational, and customer data
        return ResponseEntity.ok(new DetailedDTO());
    }

    @PreAuthorize("hasAuthority('OVERSIGHT_PERFORMANCE')")
    @GetMapping("/performance")
    public ResponseEntity<String> oversightPerformance() {
        // Logic to oversee the bank’s overall performance and strategy
        return ResponseEntity.ok("Performance oversight performed successfully");
    }
}
