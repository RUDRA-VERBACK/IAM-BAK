package com.ras.session.initial.repository;

import com.ras.session.initial.entity.FinancialData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FinancialDataRepository extends JpaRepository<FinancialData, Long> {

    // Find financial data by a specific field (e.g., data)
    List<FinancialData> findByData(String data);

    // Find financial data by value greater than a certain threshold
    List<FinancialData> findByValueGreaterThan(Double value);

    // Find financial data by a specific field and value range
    List<FinancialData> findByDataAndValueBetween(String data, Double minValue, Double maxValue);
}