package com.ras.session.initial.service.Impl;

import com.ras.session.initial.DTO.LoanApplicationDTO;
import com.ras.session.initial.entity.LoanApplication;
import com.ras.session.initial.entity.TransactionData;

public interface LoanOfficerService {
    String processLoanApplication(LoanApplicationDTO loanApplicationDTO);
    LoanApplicationDTO reviewLoanApplication(Long applicationId);
    TransactionData accessFinancialInfo(Long customerId);
    String performOtherOperations();
}