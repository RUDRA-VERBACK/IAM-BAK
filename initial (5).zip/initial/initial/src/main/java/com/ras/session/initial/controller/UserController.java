/*package com.ras.session.initial.controller;

import com.ras.session.initial.DTO.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/users")
    public ResponseEntity<UserDTO> saveUser(@RequestBody UserDTO userDTO, HttpServletResponse response) {
        UserDTO savedUser = userService.saveUser(userDTO);
        setCookie(response, "UserCookie", savedUser.getUsername());
        return ResponseEntity.ok(savedUser);
    }

    @PostMapping("/roles")
    public ResponseEntity<RoleDTO> saveRole(@RequestBody RoleDTO roleDTO) {
        RoleDTO savedRole = userService.saveRole(roleDTO);
        return ResponseEntity.ok(savedRole);
    }

    @PostMapping("/users/{username}/roles")
    public ResponseEntity<?> addRoleToUser(@PathVariable String username, @RequestBody String roleName) {
        userService.addRoleToUser(username, roleName);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/users/{username}")
    @Cacheable(value = "users", key = "#username")
    public ResponseEntity<UserDTO> getUser(@PathVariable String username, HttpServletRequest request) {
        checkCookie(request, "UserCookie", username);
        UserDTO userDTO = userService.getUser(username);
        return ResponseEntity.ok(userDTO);
    }

    @GetMapping("/users")
    @Cacheable("users")
    public ResponseEntity<List<UserDTO>> getUsers() {
        List<UserDTO> users = userService.getUsers();
        return ResponseEntity.ok(users);
    }

    private void setCookie(HttpServletResponse response, String name, String value) {
        ResponseCookie cookie = ResponseCookie.from(name, value)
                .httpOnly(true)
                .secure(true)
                .path("/")
                .maxAge(3600)
                .build();
        response.addHeader("Set-Cookie", cookie.toString());
    }

    private void checkCookie(HttpServletRequest request, String name, String expectedValue) {
        if (request.getCookies() != null) {
            for (javax.servlet.http.Cookie cookie : request.getCookies()) {
                if (cookie.getName().equals(name) && !cookie.getValue().equals(expectedValue)) {
                    throw new RuntimeException("Invalid cookie value");
                }
            }
        }
    }
}




 */