package AppIdentityManagementModule.DTO;

import lombok.Data;

@Data
public class OtpDTO {
    private String email;
    private String otp;
}
