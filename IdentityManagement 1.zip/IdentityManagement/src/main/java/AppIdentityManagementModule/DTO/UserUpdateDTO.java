package AppIdentityManagementModule.DTO;

import lombok.Data;
import java.util.Set;

@Data
public class UserUpdateDTO {
    private String username;
    private String password;
    private String email;
    private String mobileNumber;
    private Set<String> roles;
}
