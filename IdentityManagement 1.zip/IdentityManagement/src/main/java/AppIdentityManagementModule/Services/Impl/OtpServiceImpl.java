package AppIdentityManagementModule.Services.Impl;

import AppIdentityManagementModule.DTO.OtpDTO;
import AppIdentityManagementModule.Models.Otp;
import AppIdentityManagementModule.Repositories.OtpRepository;
import AppIdentityManagementModule.Services.OtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class OtpServiceImpl implements OtpService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private OtpRepository otpRepository;

    private final SecureRandom random = new SecureRandom();
    private final int otpLength = 6;
    private final int otpExpirationMinutes = 5;

    @Override
    public String generateOtp() {
        StringBuilder otp = new StringBuilder();
        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10));
        }
        return otp.toString();
    }

    @Override
    public void sendOtp(String email, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP code is: " + otp);
        mailSender.send(message);

        Otp otpEntity = new Otp();
        otpEntity.setEmail(email);
        otpEntity.setOtp(otp);
        otpEntity.setExpirationTime(LocalDateTime.now().plusMinutes(otpExpirationMinutes));
        otpRepository.save(otpEntity);
    }

    @Override
    public boolean verifyOtp(OtpDTO otpDTO) {
        Optional<Otp> otpOptional = otpRepository.findByEmail(otpDTO.getEmail());
        if (otpOptional.isPresent()) {
            Otp otpEntity = otpOptional.get();
            if (otpEntity.getOtp().equals(otpDTO.getOtp()) && otpEntity.getExpirationTime().isAfter(LocalDateTime.now())) {
                return true;
            }
        }
        return false;
    }
}

