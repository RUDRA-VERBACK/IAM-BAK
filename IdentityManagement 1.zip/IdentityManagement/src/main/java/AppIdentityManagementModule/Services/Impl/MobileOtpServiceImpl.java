package AppIdentityManagementModule.Services.Impl;

import AppIdentityManagementModule.TwilioConfig;
import AppIdentityManagementModule.Services.MobileOtpService;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class MobileOtpServiceImpl implements MobileOtpService {

    private final TwilioConfig twilioConfig;

    private Map<String, String> otpData = new HashMap<>();

    @Autowired
    public MobileOtpServiceImpl(TwilioConfig twilioConfig) {
        this.twilioConfig = twilioConfig;
    }

    @Override
    public String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate 6-digit OTP
        return String.valueOf(otp);
    }

    @Override
    public void sendOtp(String phoneNumber, String otp) {
        Message.creator(
                new PhoneNumber(phoneNumber),
                new PhoneNumber(twilioConfig.getPhoneNumber()),
                "Your OTP is: " + otp
        ).create();
        otpData.put(phoneNumber, otp); // Store OTP for verification
    }

    @Override
    public boolean verifyOtp(String phoneNumber, String otp) {
        String validOtp = otpData.get(phoneNumber);
        if (validOtp != null && validOtp.equals(otp)) {
            otpData.remove(phoneNumber); // Invalidate OTP after successful verification
            return true;
        }
        return false;
    }
}
