/*

package AppIdentityManagementModule.Services.Impl;

import AppIdentityManagementModule.DTO.UserCreateDTO;
import AppIdentityManagementModule.DTO.UserDTO;
import AppIdentityManagementModule.DTO.UserUpdateDTO;
import AppIdentityManagementModule.Models.ERole;
import AppIdentityManagementModule.Models.Role;
import AppIdentityManagementModule.Models.User;
import AppIdentityManagementModule.Repositories.RoleRepository;
import AppIdentityManagementModule.Repositories.UserRepository;
import AppIdentityManagementModule.Services.UserService;
import AppIdentityManagementModule.Exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public UserDTO saveUser(UserCreateDTO userCreateDTO) {
        User user = new User();
        user.setUsername(userCreateDTO.getUsername());
        user.setPassword(userCreateDTO.getPassword());
        user.setEmail(userCreateDTO.getEmail());
        user.setMobileNumber(userCreateDTO.getMobileNumber());
        user.setRoles(getRolesFromNames(userCreateDTO.getRoles()));

        User savedUser = userRepository.save(user);
        return mapToDTO(savedUser);
    }

    @Override
    public Optional<UserDTO> getUserById(Long id) {
        return userRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    public UserDTO updateUser(Long id, UserUpdateDTO userUpdateDTO) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        existingUser.setUsername(userUpdateDTO.getUsername());
        existingUser.setPassword(userUpdateDTO.getPassword());
        existingUser.setEmail(userUpdateDTO.getEmail());
        existingUser.setMobileNumber(userUpdateDTO.getMobileNumber());
        existingUser.setRoles(getRolesFromNames(userUpdateDTO.getRoles()));

        User updatedUser = userRepository.save(existingUser);
        return mapToDTO(updatedUser);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public List<UserDTO> getUsersByUsername(String username) {
        return userRepository.findByUsername(username).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private Set<Role> getRolesFromNames(Set<String> roleNames) {
        return roleNames.stream()
                .map(roleName -> roleRepository.findByName(ERole.valueOf(roleName))
                        .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + roleName)))
                .collect(Collectors.toSet());
    }

    private UserDTO mapToDTO(User user) {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setUsername(user.getUsername());
        userDTO.setEmail(user.getEmail());
        userDTO.setMobileNumber(user.getMobileNumber());
        userDTO.setRoles(user.getRoles().stream().map(role -> role.getName().name()).collect(Collectors.toSet()));
        return userDTO;
    }
}

 */


package AppIdentityManagementModule.Services.Impl;

import AppIdentityManagementModule.DTO.UserCreateDTO;
import AppIdentityManagementModule.DTO.UserDTO;
import AppIdentityManagementModule.DTO.UserUpdateDTO;
import AppIdentityManagementModule.Exceptions.ResourceNotFoundException;
import AppIdentityManagementModule.Models.ERole;
import AppIdentityManagementModule.Models.Role;
import AppIdentityManagementModule.Models.User;
import AppIdentityManagementModule.Models.VerificationToken;
import AppIdentityManagementModule.Repositories.RoleRepository;
import AppIdentityManagementModule.Repositories.UserRepository;
import AppIdentityManagementModule.Repositories.VerificationTokenRepository;
import AppIdentityManagementModule.Services.EmailService;
import AppIdentityManagementModule.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private EmailService emailService;

    @Override
    public UserDTO saveUser(UserCreateDTO userCreateDTO) {
        User user = new User();
        user.setUsername(userCreateDTO.getUsername());
        user.setPassword(userCreateDTO.getPassword());
        user.setEmail(userCreateDTO.getEmail());
        user.setMobileNumber(userCreateDTO.getMobileNumber());
        user.setRoles(getRolesFromNames(userCreateDTO.getRoles()));
        user.setEnabled(false);

        User savedUser = userRepository.save(user);
        createVerificationToken(savedUser);
        return mapToDTO(savedUser);
    }

    private void createVerificationToken(User user) {
        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken(token, user);
        tokenRepository.save(verificationToken);
        sendVerificationEmail(user, token);
    }

    private void sendVerificationEmail(User user, String token) {
        String toAddress = user.getEmail();
        String subject = "Email Verification";
        String content = "Dear " + user.getUsername() + ",<br>"
                + "Please click the link below to verify your email:<br>"
                + "<a href=\"http://localhost:8081/api/users/verify?token=" + token + "\">VERIFY</a>";

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(toAddress);
            helper.setSubject(subject);
            helper.setText(content, true);
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    @Override
    public void createVerificationToken(UserDTO userDTO, String token) {
        User user = userRepository.findById(userDTO.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        VerificationToken verificationToken = new VerificationToken(token, user);
        tokenRepository.save(verificationToken);

        // Send verification email using EmailService
        String subject = "Email Verification";
        String confirmationUrl = "http://localhost:8081/api/users/verify?token=" + token;
        String message = "To confirm your email address, please click on the following link: " + confirmationUrl;

        emailService.sendSimpleEmail(user.getEmail(), subject, message);
    }
    @Override
    public boolean verifyUser(String token) {
        Optional<VerificationToken> verificationToken = tokenRepository.findByToken(token);
        if (verificationToken.isPresent()) {
            VerificationToken tokenEntity = verificationToken.get();
            User user = tokenEntity.getUser();
            user.setEnabled(true);
            userRepository.save(user);
            tokenRepository.delete(tokenEntity);
            return true;
        }
        return false;
    }

    @Override
    public Optional<UserDTO> getUserById(Long id) {
        return userRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    public UserDTO updateUser(Long id, UserUpdateDTO userUpdateDTO) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        existingUser.setUsername(userUpdateDTO.getUsername());
        existingUser.setPassword(userUpdateDTO.getPassword());
        existingUser.setEmail(userUpdateDTO.getEmail());
        existingUser.setMobileNumber(userUpdateDTO.getMobileNumber());
        existingUser.setRoles(getRolesFromNames(userUpdateDTO.getRoles()));

        User updatedUser = userRepository.save(existingUser);
        return mapToDTO(updatedUser);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public List<UserDTO> getUsersByUsername(String username) {
        return userRepository.findByUsername(username).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private Set<Role> getRolesFromNames(Set<String> roleNames) {
        return roleNames.stream()
                .map(roleName -> roleRepository.findByName(ERole.valueOf(roleName))
                        .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + roleName)))
                .collect(Collectors.toSet());
    }

    private UserDTO mapToDTO(User user) {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setUsername(user.getUsername());
        userDTO.setEmail(user.getEmail());
        userDTO.setMobileNumber(user.getMobileNumber());
        userDTO.setRoles(user.getRoles().stream().map(role -> role.getName().name()).collect(Collectors.toSet()));
        return userDTO;
    }


}
