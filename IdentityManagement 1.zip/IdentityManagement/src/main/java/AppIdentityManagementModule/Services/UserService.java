package AppIdentityManagementModule.Services;

import AppIdentityManagementModule.DTO.UserCreateDTO;
import AppIdentityManagementModule.DTO.UserDTO;
import AppIdentityManagementModule.DTO.UserUpdateDTO;
import AppIdentityManagementModule.Models.Role;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface UserService {
    UserDTO saveUser(UserCreateDTO userCreateDTO);
    Optional<UserDTO> getUserById(Long id);
    UserDTO updateUser(Long id, UserUpdateDTO userUpdateDTO);
    void deleteUser(Long id);
    List<UserDTO> getAllUsers();
    List<UserDTO> getUsersByUsername(String username);
    void createVerificationToken(UserDTO userDTO, String token);
    boolean verifyUser(String token);
}
