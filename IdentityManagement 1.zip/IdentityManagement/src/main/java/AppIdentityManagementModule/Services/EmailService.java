package AppIdentityManagementModule.Services;

public interface EmailService {
    void sendSimpleEmail(String toEmail, String subject, String body);
}
