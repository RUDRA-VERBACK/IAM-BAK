package AppIdentityManagementModule.Services;

public interface MobileOtpService {
    String generateOtp();
    void sendOtp(String phoneNumber, String otp);
    boolean verifyOtp(String phoneNumber, String otp);
}
