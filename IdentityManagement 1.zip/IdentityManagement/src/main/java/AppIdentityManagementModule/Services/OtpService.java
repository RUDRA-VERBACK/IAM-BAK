package AppIdentityManagementModule.Services;

import AppIdentityManagementModule.DTO.OtpDTO;

public interface OtpService {
    String generateOtp();
    void sendOtp(String email, String otp);
    boolean verifyOtp(OtpDTO otpDTO);
}
