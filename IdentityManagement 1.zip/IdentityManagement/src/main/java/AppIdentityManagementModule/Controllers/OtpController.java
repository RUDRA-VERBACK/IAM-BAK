package AppIdentityManagementModule.Controllers;

import AppIdentityManagementModule.DTO.OtpDTO;
import AppIdentityManagementModule.Services.OtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/otp")
public class OtpController {

    @Autowired
    private OtpService otpService;

    @PostMapping("/send")
    public ResponseEntity<String> sendOtp(@RequestParam String email) {
        String otp = otpService.generateOtp();
        otpService.sendOtp(email, otp);
        return new ResponseEntity<>("OTP sent to email", HttpStatus.OK);
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyOtp(@RequestBody OtpDTO otpDTO) {
        boolean isValid = otpService.verifyOtp(otpDTO);
        if (isValid) {
            return new ResponseEntity<>("OTP verified successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid or expired OTP", HttpStatus.BAD_REQUEST);
        }
    }
}

